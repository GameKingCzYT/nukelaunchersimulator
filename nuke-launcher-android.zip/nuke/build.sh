#!/usr/bin/env bash
# Nuke Launcher: build debug APK
# Potřebuje: jdk17-openjdk, nodejs/npm, Android SDK (ANDROID_HOME) s platform-tools, platforms;android-34, build-tools;34.0.0
set -e
cd "$(dirname "$0")"
npm install
[ -d android ] || npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
echo "APK: $(pwd)/app/build/outputs/apk/debug/app-debug.apk"
